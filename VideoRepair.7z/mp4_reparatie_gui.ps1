Add-Type -AssemblyName System.Windows.Forms

# GUI setup
$form = New-Object System.Windows.Forms.Form
$form.Text = "MP4 Reparatie Tool"
$form.Size = New-Object System.Drawing.Size(400,200)
$form.StartPosition = "CenterScreen"

$label = New-Object System.Windows.Forms.Label
$label.Text = "Selecteer een MP4-bestand:"
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(10,20)
$form.Controls.Add($label)

$button = New-Object System.Windows.Forms.Button
$button.Text = "Bestand Kiezen"
$button.Location = New-Object System.Drawing.Point(10,50)
$button.Width = 150
$form.Controls.Add($button)

$logLabel = New-Object System.Windows.Forms.Label
$logLabel.Text = ""
$logLabel.AutoSize = $true
$logLabel.Location = New-Object System.Drawing.Point(10, 90)
$form.Controls.Add($logLabel)

$button.Add_Click({
    $fileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $fileDialog.Filter = "MP4 bestanden (*.mp4)|*.mp4"
    
    if ($fileDialog.ShowDialog() -eq "OK") {
        $inputFile = $fileDialog.FileName
        $dir = [System.IO.Path]::GetDirectoryName($inputFile)
        $name = [System.IO.Path]::GetFileNameWithoutExtension($inputFile)
        $outputFile = Join-Path $dir "repaired_$name.mp4"

        $ffmpegPath = Join-Path $PSScriptRoot "ffmpeg.exe"

        if (-Not (Test-Path $ffmpegPath)) {
            [System.Windows.Forms.MessageBox]::Show("ffmpeg.exe niet gevonden in scriptmap.")
            return
        }

        $logLabel.Text = "Bezig met herstel (snelle poging)..."
        $form.Refresh()

        $args = "-err_detect ignore_err -i `"$inputFile`" -c copy `"$outputFile`""
        $process = Start-Process -FilePath $ffmpegPath -ArgumentList $args -NoNewWindow -Wait -PassThru

        if ($process.ExitCode -ne 0 -or -not (Test-Path $outputFile)) {
            $logLabel.Text = "Snelle poging mislukt, hercodering gestart..."
            $form.Refresh()
            $args = "-i `"$inputFile`" -c:v libx264 -c:a aac `"$outputFile`""
            $process = Start-Process -FilePath $ffmpegPath -ArgumentList $args -NoNewWindow -Wait -PassThru
        }

        if ($process.ExitCode -eq 0 -and (Test-Path $outputFile)) {
            $logLabel.Text = "Herstel voltooid! Bestand: repaired_$name.mp4"
        } else {
            $logLabel.Text = "Herstel mislukt."
        }
    }
})

$form.Topmost = $true
[void]$form.ShowDialog()
